
function testFonctionnalites() {
	/* teste si la geolocalisation est prise en charge par le navigateur */
document.querySelector("#geoloc").innerHTML = Modernizr.geolocation ? "pris en charge" : "non pris en charge";
	/* teste si la fonctionnalite tactile est prise en charge par le navigateur */
document.querySelector("#touch").innerHTML = Modernizr.touch ? "pris en charge" : "non pris en charge" ;
	/* teste si le svg est prise en charge par le navigateur */
document.querySelector("#svg").innerHTML = Modernizr.svg ? "pris en charge" : "non pris en charge";
	/* teste si la fonctionnalite canvas est prise en charge par le navigateur */
document.querySelector("#canvas").innerHTML = Modernizr.canvas ? "pris en charge" : "non pris en charge";
}
/* pour chaque test si la fonctionnalite est bien prise en charge on affiche "pris en charge" sinon on affiche "non pris en charge" */
window.onload = testFonctionnalites;



